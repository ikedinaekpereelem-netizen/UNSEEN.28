export default function Header() {
  return (
    <header className="header">
      <div className="logo">
        <svg width="36" height="36" viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="12" cy="12" r="10" fill="currentColor" />
          <text x="12" y="16" textAnchor="middle" fontSize="10" fontFamily="sans-serif" fill="#fff">CF</text>
        </svg>
      </div>
      <h1>Coin Flash (Demo)</h1>
    </header>
  )
}
