import { useState } from 'react'

export default function CoinCard({ coin }) {
  const [flashing, setFlashing] = useState(false)
  const [message, setMessage] = useState('')

  function flashCoin() {
    // playful simulated "flash" action — nondestructive demo only
    setFlashing(true)
    setMessage('')
    setTimeout(() => {
      setFlashing(false)
      const fakeTx = Math.random().toString(36).slice(2, 12).toUpperCase()
      setMessage(`Simulated tx: ${coin.symbol}-${fakeTx}`)
    }, 900)
  }

  return (
    <div className={`card ${flashing ? 'flash' : ''}`}>
      <div className="card-header">
        <div className="badge">{coin.symbol}</div>
        <div className="price">${Number(coin.price).toLocaleString()}</div>
      </div>
      <div className="name">{coin.name}</div>
      <div className="actions">
        <button onClick={flashCoin} aria-pressed={flashing}>
          {flashing ? 'Flashing…' : 'Flash'}
        </button>
      </div>
      {message && <div className="message">{message}</div>}
    </div>
  )
}
