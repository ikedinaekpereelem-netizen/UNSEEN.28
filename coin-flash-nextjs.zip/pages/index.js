import Head from 'next/head'
import Header from '../src/components/Header'
import CoinCard from '../src/components/CoinCard'
import { useEffect, useState } from 'react'

export default function Home() {
  const [coins, setCoins] = useState([])

  useEffect(() => {
    fetch('/api/coins')
      .then(r => r.json())
      .then(setCoins)
  }, [])

  return (
    <>
      <Head>
        <title>Coin Flash — Demo</title>
        <meta name="description" content="Coin Flash demo Next.js project" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <Header />

      <main className="container">
        <h2>Available demo coins</h2>
        <div className="grid">
          {coins.map(c => (
            <CoinCard key={c.symbol} coin={c} />
          ))}
        </div>
        <footer className="footer">This is a demo. No real transfers are performed.</footer>
      </main>
    </>
  )
}
