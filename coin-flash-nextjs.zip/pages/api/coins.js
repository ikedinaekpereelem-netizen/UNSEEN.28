// Demo API returning a small list of sample coins.
export default function handler(req, res) {
  const coins = [
    { name: 'Bitcoin (demo)', symbol: 'BTC', price: 67842.12 },
    { name: 'Ethereum (demo)', symbol: 'ETH', price: 3278.55 },
    { name: 'Litecoin (demo)', symbol: 'LTC', price: 92.11 },
    { name: 'CoinFlash Token', symbol: 'CFT', price: 0.042 },
  ]
  res.status(200).json(coins)
}
