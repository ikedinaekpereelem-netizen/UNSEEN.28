# Coin Flash — Next.js Demo Project

This is a small demo Next.js app called **Coin Flash**. It's a frontend demo showing a list of sample cryptocurrencies and a playful "flash" action that simulates sending a fake coin (for demo/testing only).

## Run locally

1. Install dependencies:
   ```bash
   npm install
   ```
2. Run dev server:
   ```bash
   npm run dev
   ```
3. Open http://localhost:3000

## Notes
- This project is a demo and does **not** perform real cryptocurrency transfers.
- Use it for UI experimentation, learning Next.js, or as a starter template.
